
package DS;
import java.util.Optional;
//import javax.swing.JOptionPane;

public class MyArrayList <T> {
        
    private Object[] arr;
    private int capacity;
    private int size;
    
    public MyArrayList (int capacity){
        this.capacity = capacity;
        size = 0;
        arr = new Object[capacity];
    }
    
    public boolean isEmpty (){
        return size == 0;
    }
    public boolean isFull (){
        return size == capacity;
    }
    
    public Optional<Object> getFirst() {

        if (size == 0) {
            return Optional.empty();
        }
        return Optional.of(arr[0]);
    }
    public Object getFirst2() {

        if (!isEmpty ()) {
            return arr[0];
        }
        return -1;
    }
    
    public Object  getLast (){
        if (!isEmpty ())
            return arr[size-1];
        else
            return null;
        
    }    
    public Object  getElement (int index){
        if (index >= 0 && index < size)
            return arr[index];

      throw new IndexOutOfBoundsException(
        "Index " + index + " is out of bounds"
        );

    }

    public void AddFirst (T val){
        if (isFull())
            throw new IllegalStateException("List is full");
          //JOptionPane.showMessageDialog(null,   "can't add because capacity only " + capacity + " is full" );
        else{
            for (int i=size; i >0; i--){
                arr[i] = arr[i-1];
            }
           //System.arraycopy(arr, 0, arr, 1, size);
            arr[0] = val;
            size++;
        }
    }
    
    public void AddLast (T val){
        if (isFull())
            throw new IllegalStateException("List is full");
          //JOptionPane.showMessageDialog(null,   "can't add because capacity only " + capacity + " is full" );
        else{
            arr[size] = val;
            size++;
        }        
        
    }    
    public void AddIn (int index, T val ){
        if (isFull()){
            throw new IllegalStateException("List is full");
        }
        if (index >= 0 && index < size)
        {
            for (int i=size; i > index;i--){
                arr[i] = arr[i-1];
            }
            
//        int temp;
//        for(int i = index; i < size; i++){
//
//            temp = arr[i+1];   
//            arr[i+1] = arr[i];   
//            arr[i] = temp;       
//        }            

            arr[index] = val;
            size++;

        }
        else 
            throw new IndexOutOfBoundsException();
    }
    
    
    public void delFirst (){
        if (isEmpty()){
            throw new IllegalStateException("List is empty");
        }
        for (int i=0; i< size-1 ;i++){
          arr[i] = arr[i+1];
        }
        size--;
        
    }
    public void delLast (){
        if (isEmpty()){
         throw new IllegalStateException("List is empty");
        }
        size--;
    }    
    
    public void delIn (int index){
        if (isEmpty()){
         throw new IllegalStateException("List is empty");
        }
        if (index >=0 && index < size){
            for (int i=index; i< size;i++){
                arr[i] = arr[i+1];
            }
            size--;
        }
        else{
            throw new IndexOutOfBoundsException("Index " + index + " is out of bounds");
        }
        
    }  

    public Object Search (T element){
        if (isEmpty()){
         throw new IllegalStateException("List is empty");
        }
        for (int i = 0; i < size; i++) {
            if (arr[i] == element) {
                return i;
            }
        }

        return -1;

    }  
        
        
    public void Display (){
        for (int i=0; i<size;i++)
            System.out.println(arr[i] + "  ");
        System.out.println();
    }
    
    public T Replace (int index, int newval){
        if (index >= 0 && index < size){
            T temp = (T) arr[index];
            arr[index] = newval;
            return temp;
        }
        else{
            throw new IndexOutOfBoundsException("Index " + index + " is out of bounds");
             
        }
    
    }   

   public int length (){
        return size;
    }   
   
 
//public int binarySearch(T key) {
//    int left = 0;
//    int right = size - 1;
//    while (left <= right) {
//        int mid = (left + right) / 2;
//        T value = (T) arr[mid];
//        int cmp = value.compareTo(key);
//        if (cmp == 0)
//            return mid;
//        else if (cmp < 0)
//            left = mid + 1;
//        else
//            right = mid - 1;
//    }
//    return -1;
//}

}
