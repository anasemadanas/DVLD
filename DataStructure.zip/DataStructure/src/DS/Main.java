
package DS;

import java.util.ArrayList; 
import java.util.ArrayDeque;

public class Main {
  
    public static void sll(){
        SLLOrdered list1 = new SLLOrdered();
        list1.insert(10);
        list1.insert(20);
        list1.insert(30);
        list1.insert(40);
        list1.insert(5);
        list1.print();
        
    System.out.println("Max = " + list1.findMax());
    System.out.println("Even Sum = " + list1.sumEven());
    System.out.println("Length = " + list1.length());
    
    
        SLL list2 = new SLL();
        list2.addLast(10);
        list2.addLast(20);
        list2.addLast(30);
        list2.addLast(40);
        list2.addLast(5);
        list2.print();
        
    System.out.println("Max = " + list2.findMax());
    System.out.println("Even Sum = " + list2.sumEven());
    System.out.println("Length = " + list2.length());    
    
    }

    public static void csll(){   
    CSLL list = new CSLL();

    System.out.println("Empty? " + list.isEmpty());

    // Test addFirst
    list.addFirst(20);
    list.addFirst(10);
    list.addFirst(5);

    System.out.println("After addFirst:");
    list.print();


    list.addLast(30);
    list.addLast(40);

    System.out.println("After addLast:");
    list.print();

    list.delFirst();

    System.out.println("After delete first:");
    list.print();

    list.delLast();
    System.out.println("After delete last:");
    list.print();

    list.delLast();
    list.delLast();

    System.out.println("After deleting more:");
    list.print();

    list.delFirst();

    System.out.println("After deleting last node:");
    list.print();
    
    list.delLast();    
    }  
    
    public static void csllbook (){
        CircularSinglyLinkedList list = new CircularSinglyLinkedList();

        System.out.println("Empty? " + list.isEmpty());

        list.addFirst(10);
        list.addFirst(20);
        list.addFirst(30);

        System.out.println("After addFirst:");
        list.display();

        list.addLast(40);
        list.addLast(50);

        System.out.println("After addLast:");
        list.display();

        System.out.println("Size: " + list.getSize());


        int x = list.removeFirst();
        System.out.println("Removed First: " + x);

        list.display();

        int y = list.removeLast();
        System.out.println("Removed Last: " + y);

        list.display();

        list.removeFirst();
        list.removeLast();

        System.out.println("After more removals:");
        list.display();


        System.out.println("Size: " + list.getSize());
        System.out.println("Empty? " + list.isEmpty());     
        
    }
    
    public static void main(String[] args) {
   

        sll();
        //csll();
         //csllbook ();

    }
}
