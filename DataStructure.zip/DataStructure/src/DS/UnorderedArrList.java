
package DS;
import java.util.Optional;
//import javax.swing.JOptionPane;

public class UnorderedArrList {
        
    private int[] arr;
    private int capacity;
    private int size;
    
    public UnorderedArrList (int capacity){
        this.capacity = capacity;
        size = 0;
        arr = new int[capacity];
    }
    
    public boolean isEmpty (){
        return size == 0;
    }
    public boolean isFull (){
        return size == capacity;
    }
    public int length (){
        return size;
    }   
    
    public int getFirst() {

        if (!isEmpty ()) {
            return arr[0];
        }
        return -1;
    }
    
    public int  getLast (){
        if (!isEmpty ())
            return arr[size-1];
        else
            return -1;
        
    }    
    public int  getElement (int index){
        if (index >= 0 && index < size)
            return arr[index];

      throw new IndexOutOfBoundsException(
        "Index " + index + " is out of bounds"
        );
      //return -1;

    }

    public void addFirst (int val){
        if (isFull())
            throw new IllegalStateException("List is full");
          //JOptionPane.showMessageDialog(null,   "can't add because capacity only " + capacity + " is full" );
        else{
            for (int i=size; i >0; i--){
                arr[i] = arr[i-1];
            }
           //System.arraycopy(arr, 0, arr, 1, size);
            arr[0] = val;
            size++;
        }
    }
    
    public void addLast (int val){
        if (isFull())
            throw new IllegalStateException("List is full");
          //JOptionPane.showMessageDialog(null,   "can't add because capacity only " + capacity + " is full" );
        else{
            arr[size] = val;
            size++;
        }        
        
    }    
    public void addIn (int index, int val ){
        if (isFull()){
            throw new IllegalStateException("List is full");
        }
        if (index >= 0 && index <= size){
            for (int i=size; i > index;i--){
                arr[i] = arr[i-1];
            }
            arr[index] = val;
            size++;
        }
        else 
            throw new IndexOutOfBoundsException();
    }
    
    
    public void delFirst (){
        if (isEmpty()){
            throw new IllegalStateException("List is empty");
        }
        for (int i=0; i<size-1;i++){   //i <= size-2
            arr[i]= arr[i+1];
        }
        size--;
    }
    public void delLast (){
        if (isEmpty()){
         throw new IllegalStateException("List is empty");
        }
        size--;
    }    
    
    public void delIn (int index){
        if (isEmpty()){
         throw new IllegalStateException("List is empty");
        }
        if (index >=0 && index < size){
            for (int i=index; i< size-1;i++){
                arr[i] = arr[i+1];
            }
            size--;
        }
        else{
            throw new IndexOutOfBoundsException("Index " + index + " is out of bounds");
        }
    }  

    public int search (int element){
        if (isEmpty()){
         throw new IllegalStateException("List is empty");
        }
        for (int i = 0; i < size; i++) {
            if (arr[i] == element) {
                return i;
            }
        }
        
//     int index = 0;
//        for(int value : arr){
//            if(value == element){
//                return index;
//            }
//            index++;
//        }       
        
        return -1;
    }  
    
    public int replace (int index, int newval){
        if (index >= 0 && index < size){
            int temp = arr[index];
            arr[index] = newval;
            return temp;
        }
        else{
            throw new IndexOutOfBoundsException("Index " + index + " is out of bounds");
        }
    }  
    
    public void display (){
        for (int i=0; i<size;i++)
            System.out.print(arr[i] + "  ");
        System.out.println();
    }
    
    public void bubbleSort (){
       int temp;
       
       for (int i=0; i <size-1;i++)
           for (int j=0; j < (size-i-1); j++)
               if (arr[j] > arr[j+1])
               {
                   temp=arr[j];
                   arr[j] = arr[j+1];
                   arr[j+1] = temp;
               }

//       for (int i=1; i <=size;i++)
//           for (int j=0; j < (size-i); j++)
//               if (arr[j] > arr[j+1])
//               {
//                   temp=arr[j];
//                   arr[j] = arr[j+1];
//                   arr[j+1] = temp;
//               }
       
//    for (int i = 0; i < size-1; i++) 
//        for (int j = 0; j < size-i-1; j++) 
//            if (arr[j] > arr[j+1]) {
//
//                int temp = arr[j];
//                arr[j] = arr[j+1];
//                arr[j+1] = temp;
//            }
    }   
}
