
package DS;


public class MyQueue {
    
    private int [] arr;
    private int capacity;
    private int size;
    private int front;
    private int rear;
    
    public MyQueue (int capacity)
    {
        this.capacity = capacity;
        size =0;
        arr = new int[capacity];
        front = 0;
        rear = -1;
    }
    
    public boolean isEmpty (){
        return size == 0;
    }

    public boolean isFull (){
        return size == capacity;
    }    

    public int length (){
        return size;
        //return rear - front +1;
    }
    
    public int peek (){
        if (isEmpty()) {
            return -1;
        }
        return arr[front];
        
    }
    public int first (){
        if(isEmpty()){
        throw new IndexOutOfBoundsException("Queue is empty");            
        }
        return arr[front];
    }

    public void enque (int element){
        if (isFull ()){
            throw new IndexOutOfBoundsException("capacity full");
        }
//        if (rear == (capacity -1))
//            rear = 0;
//        else 
//            rear++;
        
            rear = (rear+1)%capacity;
            arr[rear] = element;
            size++;
    }
    
    public int deque (){
        int temp=-1;
        if (isEmpty ()){
            throw new IndexOutOfBoundsException("capacity full");
        }
//        if (front == (capacity -1))
//            front = 0;
//        else 
//            front++;
            temp = arr[front];          
            front = (front+1)%capacity;

            size--;
        return temp;
    }
    

    @Override
    public String toString() {

        String result = "Queue: ";

        for(int i = 0; i < size; i++){
            result += arr[i] + " ";
        }

        return result;
    }    

    //linear
    public void enque1 (int element){
        if (isFull2 ()){
            throw new IndexOutOfBoundsException("capacity full");
        }
            rear++;
            arr[rear] = element;
    }
    
    public int deque1 (){

        if (isEmpty2 ()){
            throw new IndexOutOfBoundsException("capacity full");
        }
            return arr[front++];
            
//        int temp=-1;            
//            temp = arr[front];
//            front++;
//        return temp;

    }
    public boolean isEmpty2 (){
        return rear < front;
    }    
    public boolean isFull2 (){
        return rear == capacity-1;
        //return top == arr.length-1;
    }
    
    
}
