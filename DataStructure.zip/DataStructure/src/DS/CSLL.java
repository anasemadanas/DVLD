
package DS;


public class CSLL {
     protected Node head;
     protected int size;

    
    public CSLL (){
        head = null;
        size=0;
    }
    public boolean isEmpty(){
        return head == null;
    }    
    public void addFirst (int element){
        Node node = new Node(element);

       if(head == null){
           head = node;
           node.next = head;
           size++;
       }       
       else{
           Node ptr = head;
           while (ptr.next != head){
               ptr = ptr.next;
           }
           node.next = head;  // set pointer to second node
           ptr.next = node;   //ptr = head , and we change to pointer node
           head = node;
           size++;
           
       } 

    }
    public void addLast (int element){ 
        Node node = new Node(element);
        
        if(head ==null){
            head = node;
            node.next =head;
            size++;
        }
        else {
            Node ptr = head;
            while(ptr.next != head)
                ptr = ptr.next;

            ptr.next = node;
            node.next = head;
            size++;
        }
        
    } 
    
    public void print(){

        if(head == null){
            System.out.println("Empty List");
            return;
        }
        Node current = head;
        do{
            System.out.print(current.element + " -> ");
            current = current.next;
        }
        while(current != head);

        System.out.println("(HEAD)");
        
    }


    public void delFirst (){
        if(head == null){
            System.out.println("Empty Node");
            return;
        }

        if(head.next == head){   // one node only
            head = null;
            size--;
            return;
        }
        
        Node ptr = head;

        while(ptr.next != head)
            ptr = ptr.next;
        
        head = head.next;
        ptr.next = head;
        size--;
    }    
    
    public void delLast (){
        if(head == null){
            System.out.println("Empty Node");
            return;
        }
        if(head.next == head){
            head = null;
            size--;
            return;
        }

          Node ptr= head;
          while (ptr.next.next != head)
              ptr = ptr.next;
          
          ptr.next = head;
          size--;
        
        }    
    public void clear(){
        head = null;
        size = 0;
    }    

}
