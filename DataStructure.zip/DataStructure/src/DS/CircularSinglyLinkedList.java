
package DS;


public class CircularSinglyLinkedList {
    private Node tail; 
    private int size;
    
    public CircularSinglyLinkedList() {
        this.tail = null;
        this.size = 0;
    }

    public boolean isEmpty() {
        return tail == null;
    }

    public int getSize() {
        return size;
    }
    public void addFirst(int element) {
        Node newNode = new Node(element);

        if (isEmpty()) {
            tail = newNode;
            tail.next = tail; 
        } else {
            newNode.next = tail.next;
            tail.next = newNode;      
        }
        size++;
    }
    public void addLast(int element) {
        Node newNode = new Node(element);

        if (isEmpty()) {
            tail = newNode;
            tail.next = tail; 
        } else {
            newNode.next = tail.next; 
            tail.next = newNode;      
            tail = newNode;           
        }
        size++;
    }
    public int removeFirst() {
        if (isEmpty()) {
            System.out.println("Empty List");
            return -1;
        }
        int removedData = tail.next.element; 
         
        if (tail.next == tail) {
            tail = null;
        } else {
            tail.next = tail.next.next; 
        }
        
        size--;
        return removedData;
    }
    public int removeLast() {
        if (isEmpty()) {
             System.out.println("Empty List");
            return -1;
        }

        int removedData = tail.element; 

        if (tail.next == tail) {
            tail = null;
        } else {

            Node ptr = tail.next; 
            while (ptr.next != tail) {
                ptr = ptr.next;
            }
            ptr.next = tail.next;
            tail = ptr;         
        }

        size--;
        return removedData;
    }
    
    public void display() {
        if (isEmpty()) {
            System.out.println("List is empty");
            return;
        }

        Node current = tail.next;
        System.out.print("List elements: ");
        do {
            System.out.print(current.element + " -> ");
            current = current.next;
        } while (current != tail.next);

        System.out.println("(HEAD)");
    }
}
