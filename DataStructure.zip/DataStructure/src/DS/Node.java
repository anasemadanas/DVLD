
package DS;

public class Node {
    public int element=0;
    public Node next;
    
    public Node ()
    {
        element=0;
        next = null;
    }
    public Node (int element)
    {
        this.element=element;
        next = null;
    }
    public Node (int element,Node Node )
    {
        this.element=element;
        next = Node;
    }
    
}
