
package DS;


public class SLLOrdered extends SLL {
    public void insert (int element){
         Node node= new  Node(element);
         Node ptr = head;
         Node prev = null;
         
         while (ptr != null){
             if (ptr.element > element)     //if found element more than new element then break         
                 break;
             else{
                prev = ptr;                //else prev = ptr node old
                ptr = ptr.next;
//                10 → 20 → 40 → 50
//                       ↑    ↑
//                     prev  ptr
             }
         }
         if(prev == null)     //if first node
         {
             node.next = head;
             head =node;
             size++;
         }
         else{
             node.next=prev.next;   //prev = 20  -- node new point to next  30 → 40 
             prev.next=node;         //link old with new node       20.next = 30;
             size++;
         }
    }
    
    public void insert2(int element){

        Node node = new Node(element);
        Node ptr = head;
        Node prev = null;

        while(ptr != null && ptr.element < element){
            prev = ptr;
            ptr = ptr.next;
        }

        if(prev == null){
            node.next = head;
            head = node;
        }
        else{
            node.next = ptr;
            prev.next = node;
        }

        size++;
    }
}