
package DS;


public class MyDeque {
    
}
