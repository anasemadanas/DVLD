
package DS;


public class OrderedArrList {
    private int[] arr;
    private int capacity;
    private int size;
    
    public OrderedArrList (int capacity){
        this.capacity = capacity;
        size = 0;
        arr = new int[capacity];
    }
    
    public boolean isEmpty (){
        return size == 0;
    }
    public boolean isFull (){
        return size == capacity;
    }
    public int length (){
        return size;
    }   
    
    public int getFirst() {

        if (!isEmpty ()) {
            return arr[0];
        }
        return -1;
    }
    
    public int  getLast (){
        if (!isEmpty ())
            return arr[size-1];
        else
            return -1;
    }    
    public int  getElement (int index){
        if (index >= 0 && index < size)
            return arr[index];

      throw new IndexOutOfBoundsException(
        "Index " + index + " is out of bounds"
        );
      //return -1;
    }

    public void delFirst (){
        if (isEmpty()){
            throw new IllegalStateException("List is empty");
        }
        for (int i=0; i<size-1;i++){   //i <= size-2
            arr[i]= arr[i+1];
        }
        size--;
    }
    public void delLast (){
        if (isEmpty()){
         throw new IllegalStateException("List is empty");
        }
        size--;
    }    
    
    public void delIn (int index){
        if (isEmpty()){
         throw new IllegalStateException("List is empty");
        }
        if (index >=0 && index < size){
            for (int i=index; i< size-1;i++){
                arr[i] = arr[i+1];
            }
            size--;
        }
        else{
            throw new IndexOutOfBoundsException("Index " + index + " is out of bounds");
        }
    }  
    
    public void display (){
        for (int i=0; i<size;i++)
            System.out.print(arr[i] + "  ");
        System.out.println();
    }

    public void insert (int element){
        if (isFull())
                  throw new IndexOutOfBoundsException("Capacity is Full");
        else{
            int i=0;
            for (i=0; i < size;i++){
                if (arr[i] > element)    //ex) i=2 
                    break;
            }
            for (int j=size;j > i;j--){
                arr[j] = arr[j-1];       //expand 
            }
            arr[i] = element;     //after expand , set new value
            size++;
        }
    }
    
    public int BinarySearch (int element){
        int first=0;
        int last= size-1;
        int mid = (last+ first)/2;
        
        while (first <= last){
            if (arr[mid] == element)
                return mid;
            else{
                if(arr[mid] < element)
                    first = mid+1;
                else
                    last = mid-1;                    
            mid = (last+ first)/2;
            }
        }
//        for (int i=0;i<size;i++){      //Linear Search
//            if (arr[i] == element)
//                return i;        }
        
        return -1;
    }    
}
