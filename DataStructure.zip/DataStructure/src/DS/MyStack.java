
package DS;


public class MyStack {
    private int [] arr;
    private int capacity;
    private int top;
    
    public MyStack (int capacity)
    {
        this.capacity = capacity;
        arr = new int[capacity];
        top = -1;
    }
  
    public boolean isEmpty (){
        return top == -1;
    }
    public boolean isFull (){
        return top == capacity-1;
        //return top == arr.length-1;
    }
    public int length (){
        if (isEmpty ()){
            return 0;
        }
        return top+1;
    }   
    public void push (int element){
        if (isFull ()){
            throw new IndexOutOfBoundsException("Stack is Full");
        }
        top++;
        arr[top] = element;
    }
    public int pop (){
        if (top == -1) {
            System.out.println("Stack is Empty");
            return -1;
        }
        return arr[top--];        
        
//        int del=-1;
//        if (isEmpty ()){
//            throw new IllegalStateException("Stack is Empty");
//        }
//        else {
//        del = arr[top];
//        top--;
//        return del;
//   
    }    


    public int peek (){
        if (top == -1)
            return -1;
        return arr[top];
        
        
//        int current=-1;
//        if (isEmpty ()){
//            throw new IllegalStateException("Stack is Empty");
//        }
//        else 
//            current = arr[top];
//            
//       return current;
    }        
    
@Override
public String toString() {

    String result = "Stack: ";
    for (int i = 0; i <= top; i++) {
        result += arr[i] + " ";
    }
    return result;
    
//    String result = "Stack:\n";
//    for (int i = top; i >= 0; i--) {
//        if (i == top) {
//            result += "TOP -> ";
//        } else {
//            result += "       ";
//        }
//
//        result += arr[i] + "\n";

}
}
