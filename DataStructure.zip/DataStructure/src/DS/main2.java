package DS;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.Enumeration;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;
import java.util.HashMap;
import java.util.Map;
import java.util.Queue;
import java.util.Stack;
import java.util.Vector;

public class main2 {
  
public static void unordered (){
        UnorderedArrList Arr = new UnorderedArrList(10);  
        //Call Add Methods
        Arr.addFirst(10);
        Arr.addFirst(15);
        Arr.addFirst(-50);
        Arr.addLast(100);
        Arr.addLast(70);
        Arr.addLast(200);
        Arr.addIn(1, 9);
        Arr.addIn(5, 1);
        Arr.addIn(0, 70);
        Arr.addIn(7, 40);        
        System.out.print("My List: ");
        Arr.display();
        
        //call Replace Method
        int r = Arr.replace(3, 2009);
        if (r != -1)
            System.out.println("The replaced element is "+r);
        else
            System.out.println("No element is replaced!");
        
        System.out.print("My List after replacement: ");
        Arr.display();
        
        //call Delete Methods
        Arr.delFirst();
        Arr.delFirst();
        Arr.delFirst();
        Arr.delLast();
        Arr.delLast();
        Arr.delIn(3);
        System.out.print("My List after deletion : ");
        Arr.display();
        
        //Call Search Method
        int s = Arr.search(100);
        if (s != -1)
            System.out.println("The element is found at index "+s);
        else
            System.out.println("The element is not found!");
        
        //Call Get Methods
        System.out.println("First Element is "+ Arr.getFirst());
        System.out.println("Last Element is "+ Arr.getLast());
        System.out.println("The element at index 2 is "+Arr.getElement(2));
        
        //Call Sort Method
        Arr.bubbleSort();
        System.out.print("My List after sorting:");
        Arr.display();
}

public static void ordered (){
        OrderedArrList ord = new OrderedArrList(10);  
        //Call insert Methods
        ord.insert(10);
        ord.insert(1);  
        ord.insert(8);
        ord.insert(-2);
        ord.insert(15);
        ord.insert(17);
        ord.insert(-1);
        System.out.print("My List: ");
        ord.display();
        System.out.println(ord.BinarySearch(8));
          System.out.println(ord.BinarySearch(15));
            System.out.println(ord.BinarySearch(12));    
             System.out.println(ord.BinarySearch(-1));    
}

public static void stackbuilt (){
    ArrayList<Integer> list = new ArrayList<>();
    list.add(30);
    list.add(40);
    
    
    Stack<Integer> s2 = new Stack<>();
    s2.push(30);
    s2.push(40);

Stack<Integer> copy = (Stack<Integer>) s2.clone();
System.out.println("copy " +copy);

    
    Stack <Integer > st = new Stack<>();

    st.addAll(list);
    st.addAll(s2);
    st.push(10);
    System.out.println(st.toString());
    
    st.clear();
    st.empty();

    
    st.push(10);
    st.push(20);
    st.push(30);
    System.out.println("push 3 : " +st.toString());  //add last (like rear)
    st.add(40);
    st.addFirst(5);
    st.addElement(60);
    
    st.firstElement();
    st.getLast();
    //st.removeAllElements();
    st.setSize(10);
    st.search(60);
    st.reversed();
    st.set(0, 10);
    st.peek();
    st.sort(Integer::compareTo);

    
    st.addLast(70);
    st.push(30);
    st.pop();
    
    System.out.println("capacity : " + st.capacity());
    System.out.println("contains : " + st.contains(50));
    System.out.println(st.toString());
    
}

public static void queuebuilt (){
    Queue<Integer> q1 = new ArrayDeque<>();
    //Queue<Integer> q2 = new LinkedList<>();
    q1.add(10);
    q1.add(20);
    q1.add(30);
    System.out.println("element: " + q1.element()); //same peek but return null if emptry
    System.out.println("offer: " + q1.offer(10));
    System.out.println("isEmpty: " + q1.isEmpty());
    q1.clear();
    System.out.println("isEmpty: " + q1.isEmpty());
    //rear  -- fifo
    q1.add(10);
    q1.add(20);
    q1.add(30);
     q1.add(40);
     q1.poll();
    System.out.println("offer : "+ q1.offer(40));
    q1.add(50);
    System.out.println("List elements");
    for (int x : q1) {
        System.out.print(x + "  ");
    }
    System.out.println();
    System.out.println("stream : "+ q1.stream());
    System.out.println("size: " + q1.size());
    System.out.println("remove :" +q1.remove());
    System.out.println("hash : "+q1.hashCode());
    System.out.println("peek : "+ q1.peek());
    System.out.println("poll : "+ q1.poll());    //same remove but return null if emptry

    System.out.println("List elements");
    for (int x : q1) {
        System.out.print(x + "  ");
    }
    System.out.println();
    System.out.println("tostring : "+ q1.toString());
    System.out.println("toarray : "+ q1.toArray());

}

public static void dequebuilt (){

    Deque<Integer> d1 = new ArrayDeque<>();
    //Deque<Integer> d2 = new LinkedList<>();
    d1.add(10);     //add rear
    d1.clear();
    d1.add(10);     //add rear
    d1.add(20);
    d1.add(30);
    d1.addFirst(5);
    d1.addLast(40);    
    System.out.println("number  elements: "+d1.element() );
    System.out.print("List elements: ");
    for (int x : d1) {
        System.out.print(x + "  ");
    } 
    System.out.println();

    System.out.println("getfirst: " + d1.getFirst());
    System.out.println("getlast: " + d1.getLast());
    System.out.println("pop : "+ d1.pop());            //front
    System.out.println("offer 10 : "+ d1.offer(10));  //same queue add front 
    System.out.println("offer  : "+ d1.offerFirst(999)); 
    System.out.println("offer  : "+ d1.offerLast(888)); 
    System.out.println("tostring : "+ d1.toString());
    System.out.println("remove 10 : " +d1.remove()); 
    System.out.println("isEmpty: " + d1.isEmpty());
    System.out.println("reversed"+d1.reversed());
 

    System.out.println("peek : "+ d1.peek());      //rear
    System.out.println("peekfirst : "+ d1.peekFirst());    //rear
    System.out.println("peeklast : "+ d1.peekLast());   //front 
    d1.push(60);      //add in first (front)
    d1.push(65);
    System.out.println("push 65 : "+ d1.toString());
    d1.push(70);
    d1.push(80);      
    d1.add(90); //add rear
    d1.add(100);
    System.out.println("tostring : "+ d1.toString());
    System.out.println("poll : "+ d1.poll());           //front
    System.out.println("pollfirst : "+ d1.pollFirst()); //front
    System.out.println("polllast : "+ d1.pollLast());   //rear
    System.out.println("tostring : "+ d1.toString());

    System.out.println("remove 60 : "+ d1.remove(60));    //number
    System.out.println("remove : "+ d1.remove());    //front
    System.out.println("removefirst : "+ d1.removeFirst());  //front
    System.out.println("removelast : "+ d1.removeLast());    //rear
    
    System.out.println("List elements : ");
    for (int x : d1) {
        System.out.print(x + "  ");
    }    
    System.out.println();
}

public static void mapbuilt (){
       Map<Integer, String> students = new HashMap<>();

        students.put(101, "Ali");
        students.put(102, "Ahmad");
        students.put(103, "Sara");
        students.put(104, "Omar");
        System.out.println(students);
        students.put(101, "Khaled");
        System.out.println(students.get(102));
         System.out.println(students.values());
         System.out.println(students.containsKey(101));
         System.out.println(students.containsValue("Sara"));
         students.remove(103);
         System.out.println(students.size());
        
        for(Map.Entry<Integer,String> e : students.entrySet()) {

            System.out.println(
                e.getKey() + " : " + e.getValue()
            );

        }         
         for(Integer key : students.keySet()) {
            System.out.println(key);
        }
        for(String value : students.values()) {
            System.out.println(value);
        }
        
            System.out.println("*".repeat(30));
        Map<String,Integer> count = new HashMap<>();

        String word = "java";

        if(count.containsKey(word)){
            count.put(word, count.get(word)+1);
        }
        else{
            count.put(word,1);
        }
        System.out.println(count);        
        
}

public static void vectorbuiltin (){
    
    Vector<Integer> v = new Vector<>();
    v.add(30);
    v.add(20);
    v.add(2,10);
    //v.removeFirst();
    System.out.println("vector = "+ v.toString());
    v.capacity();
    v.lastIndexOf(30);
    v.get(2);
    v.set(0, 60);
    v.size();
    
    v.elements();
    v.replaceAll(x -> x * 2);
    //v.setSize(10);
    
    Enumeration<Integer> e = v.elements();

    while(e.hasMoreElements()) {
        System.out.println(e.nextElement());    
    }
}

public static void listbuilt (){
         List<Integer> l = new LinkedList<>();
        List<Integer> list = new ArrayList<>();

        list.add(10);
        list.add(20);
        list.add(30);

        ListIterator<Integer> it = list.listIterator();

        System.out.println(it.next());
        System.out.println(it.next());
        System.out.println(it.previous());
        System.out.println(it.previous());
         System.out.println(it.hasPrevious());
         System.out.println(it.nextIndex());

}

public static void mystack (){
    MyStack S = new MyStack(10);
        S.push(10);
        S.push(12);
        S.push(11);
        S.push(0);
        S.push(-10);
        System.out.println("the number if elements in the stack S is = "+ S.length());
        S.push(30);
        S.push(100);
        S.push(200);
        S.push(2);
        S.push(1);
        System.out.println("the number if elements in the stack S is = "+ S.length());
        S.pop();
        S.push(100);
        System.out.println(S.toString());
        System.out.println(S.peek());
        int size = S.length();
        for (int i =0; i < size;i++){
            System.out.print(S.pop() + "  ");
            
        }
        System.out.println();

}

public static void myqueue (){
        MyQueue My_list = new MyQueue(10);
        My_list.enque(10);  // inserted at index 0
        My_list.enque(12);  // at index 1
        My_list.enque(11);  // at index 2
        My_list.enque(0);   // at index 3
        My_list.enque(-10); // at index 4
        My_list.enque(30);  // at index 5
        My_list.enque(100); // at index 6
        My_list.enque(200); // at index 7
        My_list.enque(2);   // at index 8
        My_list.enque(90);  // at index 9
        System.out.println("Dequeued element is: "+My_list.deque());
        My_list.enque(955);
        System.out.println(My_list.toString());
        System.out.println("Dequeued element is: "+My_list.deque());
        System.out.println("Dequeued element is: "+My_list.deque());
        /*
	Index:  0   1   2   3    4    5    6    7   8   9
		955 12  11   0   -10   30   100  200  2  90
	front: 
		Queue: 12 11 0 -10 30 100 200 2 90 955   // counter front
        */        
        My_list.enque(955);
    System.out.println(My_list.toString());
    
}

    public static void ex1 (){
    // عمل اوبجيكت ولكن الذي انا عملته وليس الخاص بجافا
    MyStack AnasStack = new MyStack(5);
    MyQueue AnasQueue = new MyQueue(5);
    // اضافة القيم في  كيو
    AnasQueue.enque(10);
    AnasQueue.enque(20);
    AnasQueue.enque(30);
    AnasQueue.enque(40);
    AnasQueue.enque(50);
    System.out.println(AnasQueue.toString());  //fifo شرح الدكتور حيث اول قيمة انضافت هي التي بتخرج اولا
    //1 Move from a Queue all its entries onto a Stack.   المطلوب نقل قيم كيو الى ستاك
    while (!AnasQueue.isEmpty())
    {
        AnasStack.push(AnasQueue.deque());   // fifo to lifo  (top = front in queue)
    }
    System.out.println(AnasStack.toString());  //lifo شرح الدكتور انس حيث القيم انتبه ان عملية بوب بتشيل من نهاية القائمة وليس من البداية بخلاف كيو يعني من اليمين
}
    public static void ex2 ()    {
    // عمل سعة لوضع القيم فيها
    MyStack AnasStack = new MyStack(5);
    MyQueue AnasQueue = new MyQueue(5);
    // اضافة القيم في ستاك 
    AnasStack.push(10);
    AnasStack.push(20);
    AnasStack.push(30);
    AnasStack.push(40);
    AnasStack.push(50);
    System.out.println(AnasStack.toString());    //lifo (top)
    //2 Move from a Stack all its entries into a Queue.  المطلوب عكس السؤال الاول نقل من ستاك الى كيو
    while (!AnasStack.isEmpty())
    {
        AnasQueue.enque(AnasStack.pop());    // lifo to fifo هنا ستجد القيم معكوسة لانو اول قيمة في ستاك تكون في الاخير بخلاف السؤال السابق لم يتغير شيء في الترتيب
    }    
    System.out.println(AnasQueue.toString());    //fifo (top = front) 

}
    public static void ex3 ()    {
    // عمل سعة لوضع القيم فيها
    MyStack AnasStack = new MyStack(5);
    MyQueue AnasQueue = new MyQueue(5);
    MyStack tempStack = new MyStack(5);
    // اضافة القيم في ستاك 
    AnasStack.push(10);
    AnasStack.push(20);
    AnasStack.push(30);
    AnasStack.push(40);
    AnasStack.push(50);
    //3 Use a temporary Stack to reverse the order of the entries of a Queue.  المطلوب عند تحويل من ستاك الى كيو ولكن ان تاتي القيم مرتبة في كيو بخلاف السؤال السابق
    // الحل ندمج لووب السؤال الاول والثاني فقط

    System.out.println("Anas Stack => "+ AnasStack.toString());  //fifo شرح الدكتور حيث اول قيمة انضافت هي التي بتخرج اولا
    //1 
    while (!AnasStack.isEmpty())
    {
        tempStack.push(AnasStack.pop());    // عكسنا قيم الستاك الاولى من اجل ادخالهم في كيو بشكل مرتب
    }
    System.out.println("temp stack => "+ tempStack.toString());  

    //2 
    while (!tempStack.isEmpty())
    {
        AnasQueue.enque(tempStack.pop());    // ادخل قيم في الكيو بشكل مرتب بعد عكسهم في ستاك
    }    
    System.out.println("           => "+AnasQueue.toString());    
    }
    public static void ex4 ()    {
    // عمل سعة لوضع القيم فيها
    MyStack s1 = new MyStack(5);
    MyStack tempstack = new MyStack(5);
    MyStack s2 = new MyStack(5);
    s1.push(10);
    s1.push(20);
    s1.push(30);
    s1.push(40);
    s1.push(50);
    System.out.println("s1 Stack   => "+ s1.toString());
    
    //4 Empty one Stack (𝑆1) onto the top of another Stack (𝑆2) 
    //in such a way that the entries that were in (𝑆1) Stack keep the same order.
    // كما ذكرنا في السؤال الثالث حيث عملنا مرتين ستاك وهذا جعل القيم معكوسة الان المطلوب بعد عكسهم ارجاعهم بشكل مرتب
    while (!s1.isEmpty())
    {
        tempstack.push(s1.pop());    // عكسنا قيم الستاك الاولى
    }
    System.out.println("temp Stack => "+ tempstack.toString());
    while (!tempstack.isEmpty())
    {
        s2.push(tempstack.pop());    // ارجعنا القيم بشكل مرتب
    } 
    System.out.println("s2 Stack   => "+ s2.toString());
    
    }
    public static void ex5 ()    {
    // عمل سعة لوضع القيم فيها
    MyStack s1 = new MyStack(5);
    MyQueue tempQueue = new MyQueue(5);
    MyStack s2 = new MyStack(5);
    s1.push(10);
    s1.push(20);
    s1.push(30);
    s1.push(40);
    s1.push(50);
    System.out.println("s1 Stack   => "+ s1.toString());
    //5 Use a temporary Queue to reverse the order of the entries of a Stack.        
    // المطلوب نقل عناصر الستاك الاولى الى الثانية ولكن بشكل معطوس بخلاف السؤال الرابع وذلك عن طريق كيو
    while (!s1.isEmpty())
    {
        tempQueue.enque(s1.pop());     // ادخال قيم ستاك حيث ستدخل معكوسة من خلال كيو مثل السؤال السابق ولكن كان عن طريق ستاك
    }   
    System.out.println("tempQueue   => "+ tempQueue.toString());
    while (!tempQueue.isEmpty())
    {
        s2.push(tempQueue.deque());   
        // بعد عكس القيم ادخلناهم الى الستاك الثانية عن طريق كيو وستدخل بشكل مرتب كما ذكرنا في السؤال الاول حيث التحويل من كيو لستاك يحافظ على الترتيب
    }
    System.out.println("s2 Stack   => "+ s2.toString());
    }
    public static void ex6 ()    {
    // عمل سعة لوضع القيم فيها
    MyStack s1 = new MyStack(5);
    MyStack s2 = new MyStack(5);
    s1.push(10);
    s1.push(20);
    s1.push(30);
    s1.push(40);
    s1.push(50);
    
    //6 Empty one Stack (𝑆1) onto the top of another Stack (𝑆2) in such a way  that 
    //the entries that were in (𝑆1) Stack are in the reverse of their original  order.
    // المطلوب عكس قيم الستاك الاولى ووضعها في الستاك الثانية وبعدها ارجاع القيم للستاك الاولى بحيث ترجع بنفس الترتيب
    System.out.println("s1 Stack      => "+ s1.toString());
    while (!s1.isEmpty())
    {
        s2.push(s1.pop());
    }
    System.out.println("s2 Stack       => "+ s2.toString());
    while (!s2.isEmpty())
    {
        s1.push(s2.pop());
    }    
    System.out.println("s1 Stack reserve  => "+ s1.toString());
}
    

    public static void sllnode (){

        Node n3 = new Node(30);
        Node n2 = new Node(20, n3);
        Node n1 = new Node(10, n2);
        
        Node head = n1;
        
        Node current = head;

        while (current != null) {
            //System.out.print(current + "   ");    //tostring
            System.out.print(current.element + " -> ");
            current = current.next;

        }
        System.out.println(n3.next);
        System.out.println("null");
    }
            
    public static void main(String[] args) {
//        System.out.println("exercise 1");
//        ex1 ();
//        System.out.println("exercise 2");
//        ex2 ();
//        System.out.println("exercise 3");
//        ex3 ();
//        System.out.println("exercise 4");
//        ex4 ();
//        System.out.println("exercise 5");
//        ex5();
//          System.out.println("exercise 6");
//          ex6 ();
        //unordered ()
        //ordered ();
        //queuebuilt ();
        //dequebuilt ();
        //stackbuilt ();
        //vectorbuiltin ();
        //mapbuilt ();
        //listbuilt ();
        //mystack ();
        //myqueue ();       
        //sllnode();
        //sll();

    }        
}
