
package DS;


public class SLL {
    protected Node head;
    protected int size;
    public SLL (){
        head = null;
        size=0; 
    }
    public boolean isEmpty (){
        return head == null;
    }
    public void addFirst (int element){
        Node node = new Node(element);
        node.next=head;
        head = node;
        size++;
    }
    public void addLast (int element){ 
        Node node = new Node(element);
        Node ptr = head;
        
        if(isEmpty()){
            head = node;
            size++;
        }
        else {
            while(ptr.next != null)
               ptr= ptr.next;

            ptr.next = node;
            size++;
        }
    } 
    
    public void addIn (int val , int element){
        Node node = new Node(element);
        Node ptr = head;
        while(ptr != null){
            if (ptr.element == val)
                break;
            else
                ptr = ptr.next;
        }
        if (ptr == null){
            //System.out.println("Element not found");
            addFirst (element);
        }
        else 
        {
            node.next = ptr.next;  
            ptr.next = node;       //pointer  ( ptr | ptr.next -> node
            size++;
        }
        
    }        
    public void delFirst (){
        if(head == null){
            System.out.println("Empty Node");
            return;
        }
        head = head.next;
        size--;
    }    
    public void delLast (){
        if(head == null){
            System.out.println("Empty Node");
            return;
        }
        if (head.next == null){
            head = null;
            size--;
        }
        else{
          Node ptr= head;
          while (ptr.next.next != null)
              ptr = ptr.next;
          
          ptr.next = null;
          size--;
        }
        
    }    
    public void delIn (int val){
        if(head == null){
            System.out.println("Empty Node");
            return;
        }
       
        Node ptr1 = head;   //ptr want delete
        Node ptr2 = null;   //want pointer to after ptr1 after delete
 
        while(ptr1 !=null){
         if (ptr1.element == val)   // stop in node delete
             break;
         else {
            ptr2 =ptr1;
            ptr1 = ptr1.next;
            }
        }
        if (ptr1 !=null){
            if (ptr2 == null) {    //if ptr1.element is first then ptr2 = null
                head = head.next;
                size--;
            }
            else{
                ptr2.next = ptr1.next;
                size--;
            }
        }
        else
            System.out.println("Nothing to Delete");
    }        
    
    public void sort (){
        if (isEmpty())
            System.out.println("The List is Empty");
        else {
            Node ptr1= head;    //before ptr2
            Node ptr2= null;    //after ptr1
            int temp;
            while(ptr1 !=null){
                ptr2 = ptr1.next;     // ptr1 --- ptr2
                while (ptr2 != null) {
                    if (ptr1.element > ptr2.element)
                    {
                        temp = ptr1.element;
                        ptr1.element = ptr2.element;
                        ptr2.element = temp;
                    }
                    ptr2 =ptr2.next;
                }
                ptr1 =ptr1.next;
            }
            
        }
        
    }
    

    public void print(){ 
        Node current = head; 
        while (current != null)
        {   
            System.out.print(current.element + " -> "); 
            current = current.next; 
        } 
        System.out.println("null "); 
    }

    public int findMax(){
        if (head == null)
            return -1;
        
        int max = head.element;
        Node current = head.next;
        while (current != null){
            if (current.element > max)
                max = current.element;  
            
            current = current.next;
        }
        return max;
    }   
    
    public int sumEven(){
       int sum=0;
       Node current = head;
       while (current != null){
           if (current.element % 2 == 0)
               sum += current.element;
           
           current = current.next;
       }
       
        return sum;
    }
    
    public int length(){
        //return size;
       int counter=0;
       Node ptr = head;
       while(ptr != null)
       {
           counter++;
           ptr = ptr.next;
       }
    
    return counter;
    }
    
    public boolean search (int element) {
        Node ptr = head;
        while (ptr != null){
            if (ptr.element == element) {
                return true;
            }
            ptr = ptr.next;
        }
        return false;
    }
    
    public void clear (){
        head=null;   //other garbage delete
        size = 0;
    }
    
    public int getFirst (){
        if(head == null)
            throw new RuntimeException("Empty List");
        return head.element;
    }    
    public int getLast (){
        if(head == null)
            throw new RuntimeException("Empty List");
        
        Node ptr = head;
        while (ptr.next != null){
            ptr = ptr.next;
        }
        return ptr.element;

    }        
}
